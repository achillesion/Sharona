// import logo from './logo.svg';
import './App.css';
// import {Canvas,useFrame, useThree} from '@react-three/fiber'
// import {Image,Text,Float,useGLTF,PerspectiveCamera,Html,RoundedBox, Text3D, OrbitControls,Plane,useVideoTexture} from '@react-three/drei'
// import { EffectComposer, HueSaturation,DepthOfField, Bloom, Noise, Vignette, SMAA } from '@react-three/postprocessing'
// import { Suspense, useRef, useState,useEffect } from 'react';
// import * as THREE from 'three';
import Webgl from './Webgl';
// import Preloader from './Preloader';

function App() {


  return (

    <>
      {/* <Preloader /> */}
      <Webgl />
    </>
  );
}

export default App;
