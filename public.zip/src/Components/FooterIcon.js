import React from 'react'

const FooterIcon = () => {
  return (
    <div className='social-icons'>

    <i className="bi bi-discord"></i>
    <i className="bi bi-twitter"></i>
    <i className="bi bi-instagram"></i>

    </div>
  )
}

export default FooterIcon